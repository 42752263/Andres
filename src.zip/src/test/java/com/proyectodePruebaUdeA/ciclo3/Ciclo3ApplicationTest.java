package com.proyectodePruebaUdeA.ciclo3;

import static org.junit.jupiter.api.Assertions.*;

class Ciclo3ApplicationTest {

}